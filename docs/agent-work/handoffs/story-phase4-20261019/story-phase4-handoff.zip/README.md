# Portable Phase 4 audit handoff

Extract into a separate evidence directory. Do not automatically overlay these files onto a checkout or execute reference helpers.

Read spec/original-brief.txt, spec/Story-mode-programme-plan.md (owner clarification0b overrides older details), and the first User-requested audit and takeover checkpoint in docs/agent-work/story-mode-20261017.md. The rest of the work record is chronological history. Verify claims against source, CI and actual runtime evidence.

Source: https://github.com/kromate/joinallworld, branch story/phase4-realism at96e2e155eec6aee6efe8509e51f942ff16ac92f7. main was3010cc17e7efe02fd4ffff70409ff1a0e4bf1c0b at export; refetch current state. Phases1-3 have recorded production acceptance. Phase4 was not merged or released by the prior owner. Latest handoff and this bounded evidence were uncommitted locally; GitHub alone does not contain them.

All /Users, /tmp and /private/tmp references, PIDs, profiles, localhost ports, process handles, locks and private provider-file references describe the old Mac. They are NOT resources on the receiving computer. Use an isolated checkout and your own test environment. No credentials, cookies, saved-game database, browser profile or .git directory are included. Do not request or transplant live customer saves. Synthetic fixture references are historical evidence, not an available authenticated session.

The long18km walk was a prior verification choice, not an owner distance requirement. Audit the smallest legitimate representative street door/return/reload proof. Record fixture setup honestly; do not claim seeded progress as observed earning or change production state to fabricate proof.

The optional helper-r2 was source-reviewed and15 pure boundary cases passed; it NEVER ran against the game. It hardcodes old-machine identities. Do not run it unchanged or spend time reproducing the old control machinery. Use tools suitable for your host. Existing screenshot/performance evidence is desktop phone-tier only and build-specific. Failures, omitted payload references and corrected measurements remain explicitly labelled.

The339-file preliminary evidence inventory is included with hashes. The timeout packet and final handoff/reference files are additional. Some original manifests refer to private-only omitted payloads: those entries remain references, not bundled evidence. MANIFEST.json lists exactly what this ZIP contains. Verify it before relying on evidence. No missing artifact is silently promoted to verified.

Private drafts contain pending placeholders and must be rewritten after actual final validation and release. Complete normal PR/CI/merge/protected release and verify production, original Durable Object namespace and R2 binding; keep the Story admin flag default off. Never raise a budget or repeat the paid dialogue probe merely to reproduce old bookkeeping.
