# Story Phase 4 final-H evidence packet

Source identity: `96e2e155eec6aee6efe8509e51f942ff16ac92f7` (H).

This packet preserves three sealed cohorts, each under `cohorts/` with its original manifest and all manifest-named files: `cold-remaining` (8 accepted cases), `warm` (9 10-second windows), and `lifecycle` (10 venue windows across five park/market cycles). The earlier `cold-original-partial` cohort is separate and unchanged. `accepted-eight-relative-index.json` maps original accepted-eight records to packet-relative receipt/PNG paths and retains the rejected Nairobi 320 capture as an explicit exclusion. The original accepted-eight file is copied unchanged.

Cold evidence: Accra 320/390, Nairobi 320/390, Paris 320/390, Tokyo 320/390. The original Nairobi 320 overlay case remains rejected; its replacement is separately represented. Collector-observed ordinary dismissal occurred in-clock for Paris 320 and Tokyo 320. The two initial native-ready observations had identical complete UUID sets; screenshot-time captures add two non-player roots, while visible native/player models remain ready. The capture-bound addendum normalizes original Accra timing to 919.8/915.7 ms; accepted times span 873.8–1015.1 ms.

Warm evidence: Accra, Paris, and Kurmi (Kano), three windows each. Actual sealed95 timing metrics are included at `baselines/phase3-95a878bd/metrics/warm.json`, with its hash-bound verification. Raw per-frame interval arrays are unavailable, so there is no independent quantile recomputation. The earlier negative visual-baseline reference check is preserved separately; `baseline/baseline.json` is a visual capture manifest without P95 metrics. The actual metrics binding supersedes only that reference gap.

Lifecycle evidence: five park-to-market cycles, ten accepted venue windows, five market returns. Market texture observations are 54, 64, 76, 86, 96; geometry/population counts are preserved per endpoint and confirmation. No plateau, inherited leak fix, identical-slope, or sole-cause claim follows.

Conditions and limits: Desktop Chrome at 390x844 for warm/lifecycle, and desktop Chrome configured for phone tier with 1024 shadows for cold. This is not physical-phone or GPU proof. Cold timing is cache-disabled existing-life navigation after observed onboarding, not first-ever use. Warm baseline comparisons have population, time, camera, viewport, and other condition differences and support no causal speedup claim. No public authenticated Talk claim is present. PNG validation only read signatures and IHDR dimensions; no image pixels were inspected.

Validation evidence, source copies (`.py.txt`), receipts, and run summaries are under `validation/`. The exact copy list is the sibling `COPY-ALLOWLIST.txt`; packet integrity records are `packet-manifest.json` and `PACKET-MANIFEST.sha256` (the latter is outside the packet).
