# Pinned incoming-main impact review

Reviewed `6c5e8b784fdcdd75b6888ba42b3190e9d284f660` → `e84d6ee7844a851911438fa4b8227587f1aba4ab`, against frozen H `96e2e155eec6aee6efe8509e51f942ff16ac92f7`. No merge or checks executed.

No source blocker found. Three commits change 18 files. All after blobs are pinned and verified; `blob-inventory.json` records exact before/after/H blob and SHA256 values. Changes comprise the privacy route/footer/reserved path, PWA screenshot metadata and five PNGs, Near you ID deduplication, tests and store documentation.

The 24 owned Phase4 files and all three canonical manifest pins still match accepted H. Incoming paths have zero intersection with their declared dependencies. No regeneration is indicated. Native rendering, street authority, Chapter3 route, door/return and gameplay assets are untouched.

Only `server/feed/service.ts` overlaps H: incoming lines263–269 deduplicate Near you IDs; H lines601–610 preserve cover media until badge validation succeeds. These are disjoint hunks; textual integration is expected to be clean but remains unexecuted. Preserve both rather than adopting the entire incoming file.

Earlier static/city/disposal/content proof may inherit for unchanged code. H timing and lifecycle numbers retain their original build and conditions; they are not new merged measurements. Ordinary H route progress remains valid, while door→Return→reload still needs the operator's receipt. No repeat of the long walk or broad graphics matrix is justified solely by these changes.

After the route finishes and the host drains: refresh main, integrate normally, inspect both feed hunks and accepted pins, run exact combined CI/package checks and focused privacy/SEO/registry/feed/paths tests. The new footer can alter startup bytes: require the original196100 Brotli cap, not196300. H had only286 bytes margin. Verify `/privacy`, all five packaged screenshot assets, entry320/390 and native preview, then a finite merged-artifact venue/return/reload smoke. No layout or GLB rebuild is needed for this pinned delta.

Release still needs normal PR/combinedCI/merge, exact-main protected release and fresh control-plane/public adoption with original DO namespace continuity. Story remains default off. No legal-policy, physical-phone, GPU leak-fix or completed route claim is made from incoming documentation.

`REVIEW.json` provides line pointers, all18 file pins, dependency intersections, inheritance limits and precise remaining gates. Source/Git/index/docs/browser/server/provider state was untouched; only this private evidence package was written.
