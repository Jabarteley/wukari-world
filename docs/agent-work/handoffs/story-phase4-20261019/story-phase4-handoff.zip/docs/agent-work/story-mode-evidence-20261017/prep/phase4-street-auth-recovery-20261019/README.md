# Street auth and idle-readiness evidence packet

The packet binds the sealed auth-recovery and post-pause readiness cohorts to frozen H `96e2e155eec6aee6efe8509e51f942ff16ac92f7`, plus the pinned idle-readiness source review. Manifest-listed evidence is copied with byte/hash preservation; `observer.js` is stored as `observer.js.txt` with its mapping recorded.

The idle receipt supports only a source-level recommendation: on-demand idle is expected; an ordinary camera drag should wake both counters with the same journey/state; mode, venue, and three clear-ready observations may plateau again. Actual gesture proof is still unproved, so controller/route resumed is not established. No auth cookies, credentials, private game database, or referenced source files were copied.
