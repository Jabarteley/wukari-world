# Ibadan manifest-only shortest tile-presence advisories

Source revision: `96e2e155eec6aee6efe8509e51f942ff16ac92f7`.
Manifest SHA-256: `e4b409c4f64f2901621679ab43dfb8c3d94887e3af19693e07df18d211d47d73` (`public/assets/street/ibadan/manifest-street-v1-25a019ef30689d00.txt`).
Method: deterministic BFS over the 7,225 manifest tile coordinates, four orthogonal neighbors, tie order west/east/south/north. It does not open/decode tile payloads. Tile size/bounds are 128m, per `src/street/frame.ts:4-12`.

## Coverage result
Both advisories terminate in Dugbe Amala's tile `(-43,-6)`. Initial Akinyele tile `(-13,-137)` path is 165 tile hops (166 tiles); reported current point `(-1616.17,-17152.04)` floors to present tile `(-13,-135)`, with a 163-hop path (164 tiles). Both paths have 61 direction-change junctions. Tile hops are graph steps only, not metres traveled or route length.

Current tile bounds: x `[-1664,-1536)`, z `[-17280,-17152)`. Its immediate present orthogonal neighbors are east `(-12,-135)` and south `(-13,-136)`; west `(-14,-135)` and north `(-13,-134)` are absent. The two additional present diagonals are northeast `(-12,-134)` and southeast `(-12,-136)`. Their bounds are included in the JSON. This is presence evidence only; no guidance should be treated as a movement command.

The deterministic current-path prefix is `(-13,-135) → (-12,-135) → (-12,-134) → (-12,-133) …`; the initial path prefix is `(-13,-137) → (-12,-137) → (-12,-136) → (-12,-135) …`. Junction indices and full ordered tile lists with each tile's x/z bounds are in the JSON output.

**Limit:** These sequences prove only that manifest tile coordinates connect. They do not inspect ground masks and cannot certify walkability, seam continuity, collision-free movement, or that any tile sequence is an executable route. Astra must continue relying on fresh visible terrain and unchanged live authority checks.

Executed script: `/private/tmp/ibadan_presence_advisory_20261019.py` (SHA-256 `8836e071a37e648f597b5d5a3d8cbf67de0fbb10acacd72ec7a390467175d996`).
JSON output: `/private/tmp/ibadan_presence_advisory_20261019.json` (SHA-256 `0d6c1f62e24f22b96b95e0eca8e770214165929a4b23d6a8d86041f293637404`).
