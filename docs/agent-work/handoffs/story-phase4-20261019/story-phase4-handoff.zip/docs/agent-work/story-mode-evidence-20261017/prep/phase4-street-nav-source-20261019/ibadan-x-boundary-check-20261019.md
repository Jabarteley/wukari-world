# Ibadan x-edge source check

Pinned source: `96e2e155eec6aee6efe8509e51f942ff16ac92f7`.
Manifest SHA-256: `e4b409c4f64f2901621679ab43dfb8c3d94887e3af19693e07df18d211d47d73`.
Affected pack file SHA-256: `0c108ff79ae9600afc3f4ecf1e0ad92c80381959284530e2a263177acdb325b7`.

## Evidence / interpretation
- `src/street/frame.ts:4-12` defines 128m tiles and `tileOf` uses `Math.floor`. At global x=-1664.00, `x / 128 = -13` exactly; at z=-17507.98, `tileOf` is `{x:-13,z:-137}`. The x=-1664 line is the west edge of tile -13.
- The pinned Ibadan manifest maps tile `(-13,-137)` to the affected pack, and has no tile `(-14,-137)`; a bounded check also found no `(-14,z)` for z=-139…-135. In `(-13,-137)`, local z is 28.02m (ground row 14); its first 8 x-cells are all walkable (`11111111`). So the pinned tile does not show an authored blocked mask at the reported inside-edge cell. Data west of the seam is absent, so this points to a map-coverage/tile-edge boundary as the likely cause; it cannot prove the visible blue/tan feature is not a real shoreline outside the mapped tile.
- `src/street/renderer.ts:82-86` initializes the 384m local grid as blocked, then opens cells only for resident tiles whose ground mask is walkable. `server/street/assets.ts:140-147` returns a valid all-zero ground tile for a coordinate absent from the manifest. Therefore an omitted western tile behaves as blocked terrain without a tile-load error. Server move validation also checks the traversability mask (`server/street/authority.ts:67-78`).

## Existing observability limitation
`src/street/host.ts:213-214` exposes journey/avatar coordinates and tile resident/pending/queued/error counters, plus scenery origin. `src/street/window.ts:34` snapshots tile arrays internally, but host diagnostics omit their coordinates. Because an out-of-manifest tile is returned as valid empty ground, diagnostics need not show an error. Thus the actor position plus visible terrain and the pinned manifest establish the likely seam, but no exposed runtime diagnostic directly names the omitted neighbor. No movement or authority adjustment is supported by this finding.
