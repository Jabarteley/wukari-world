# Ibadan manifest tile-presence graph

Pinned source revision: `96e2e155eec6aee6efe8509e51f942ff16ac92f7`.
Manifest: `public/assets/street/ibadan/manifest-street-v1-25a019ef30689d00.txt`, SHA-256 `e4b409c4f64f2901621679ab43dfb8c3d94887e3af19693e07df18d211d47d73`.

The manifest has 7,225 tile coordinates; 4-neighbor BFS finds one component of 7,225 tiles, bbox x `[-346,247]`, z `[-390,318]`. Start `(-13,-137)` and all three target tiles are present in that component:

- Dugbe Amala `(-43,-6)`: 165 tile hops (Manhattan tile-index delta 161).
- Mapo Hall `(-29,3)`: 174 tile hops (Manhattan delta 156).
- Polling `(-28,4)`: 174 tile hops (Manhattan delta 156).

The nearest forward-north row with connected western neighbor `(-14,z)` is `z=-103`, covering global z `[-13184,-13056)`; its tile hop distance from the start tile is 38. The first contiguous present run is z `-103…-98`; next present row is `-93` (so presence is not continuous in every north row). These are tile-hop counts, not metre-route estimates.

This result establishes manifest tile-coordinate connectivity only. It does not inspect tile masks or prove any traversable ground path, walkable seam continuity, or route; blocked cells/water may still divide the tile component. Tile size and floor-based coordinate mapping are defined by `src/street/frame.ts:4-12`.

Reproduction: run `/private/tmp/ibadan_tile_presence_graph_20261019.py`; it parses only the manifest coordinate index and uses 4-neighbor BFS, without unpacking tile payloads. Output JSON: `/private/tmp/ibadan_tile_presence_graph_20261019.json`.

Script SHA-256: `5f231dcd783cafc91f4ebfb763ad7bfdb6d958739e8377b4b716c19aee29e1f9`.
JSON SHA-256: `9303848801a02ca160f7ded4b23a46fc5b0331873c08770fc6a573c2f7b307b9`.
