# Reusable Ibadan manifest-presence advisory CLI

CLI: `/private/tmp/ibadan_presence_route_cli_20261019.py`. It accepts `--x` and `--z` observed global metres, checks `git rev-parse HEAD` against pinned source `96e2e155eec6aee6efe8509e51f942ff16ac92f7`, verifies the manifest SHA-256 `e4b409c4f64f2901621679ab43dfb8c3d94887e3af19693e07df18d211d47d73`, verifies Ibadan/version/tile size, caps manifest entries at 100,000, validates finite values and manifest bounds, and fails with neighboring tile-presence facts if the floored input tile is absent. It prints advisory JSON only; errors go to stderr. It imports no project/app code, makes no network calls, and reads no tile packs or ground masks.

Exact execution: `python3 /private/tmp/ibadan_presence_route_cli_20261019.py --x -1562.73 --z -13850.78`.

Result: current tile `(-13,-109)` present; Dugbe target `(-43,-6)` present; shortest tile-presence path 133 hops. Fixed-order BFS has 54 direction changes; minimum-turn among shortest paths has 40. Minimum-turn prefix is `(-13,-109), (-13,-108), (-13,-107), (-13,-106), (-13,-105), (-13,-104), (-13,-103), (-13,-102), (-13,-101), (-13,-100)`. Immediate presence neighbors: west `(-14,-109)` absent, east `(-12,-109)` present, south `(-13,-110)` absent, north `(-13,-108)` present. Full path tiles/bounds and junctions are in the JSON.

This result is tile-coordinate presence only. It does not certify ground traversability, seam continuity, collision-free movement, or a game action, and must not be used as a controller command. Parent review is required before any advisory use; actual steering remains based on fresh visible terrain and live authority.

Script SHA-256: `c98931ee5e1f0ecdd627b02d445c4e9152c4d620db8e19aad7f83b271c5be866`.
Captured JSON SHA-256: `1b30e0d70cea5413232ce213dcb44f3bde6b2036091f0db16d43841e29d22072`.
