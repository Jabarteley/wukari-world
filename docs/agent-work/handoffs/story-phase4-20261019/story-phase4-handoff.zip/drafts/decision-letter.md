Anthony, I resolved the remaining routine choices within your brief. This draft is pending the final street proof, merge and Phase 4 production adoption; it is not a completion claim.

Free Roam stays the default for every existing life. Story is a reversible per-character switch through Passport/Home, with earned receipts preserved in both modes and server-owned gates. The production storyMode setting stays off by default, as requested. Every already-open city may be the first Story city; the current city becomes the start. I recommend a one-time Story offer after the first tale, but that extra discovery card is not implemented.

The factory ships 6,423 scene recipes across 284 cities using 14 regional kits and 284 city landmarks:298 Blender model assets, not 6,423 independent Blender projects. Authored Nigerian variants remain. The rejected schematic asset batch was retained; the accepted rebuild and static paired review use the physical atlas and sourced landmark briefs. These checks do not certify photorealism or perceptual/geographic uniqueness of every scene.

The realism pass reuses the existing atlas and geometry, with bounded sky grading, material variation, grime and bands. I retained the existing phone 1024 PCF / wide 2048 soft shadow policy because that shared performance code remains owned elsewhere. I omitted uniform window rows because the same atlas also covers gates and kiosks; actual building geometry keeps its windows. I fixed our surface attribute disposal order and verified its event ordering. Repeated visits still grow texture counts, including in the exact pre-Phase 4 contrast, so I did not label that inherited growth fixed or attribute it to one cause.

The mapped street flow retains the actual estate gate, server journey, terrain/sequence/rate authority, eligible door and return. The street proof uses ordinary jogging from the earned Ibadan life under the existing cooldown, terrain, time and progression rules. Existing timed travel remains available. Tile-presence connectivity only supports navigation; it is not proof that every ground seam is walkable. A corner produced an existing unavailable error; two ordinary ground taps with separate server acknowledgements recovered the same journey. The exact failed request was not captured, and the protected street implementation is unchanged.

Dialogue uses shipped filtered banks for common intents and the existing provider/router for optional free text. One accepted warmed paid line took 1,353.752916 ms for the turn and cost 17 microdollars ($0.000017) in the ledger. That is one warmed observation, not a reliability, cold-turn, invoice or public authenticated Talk claim. No further paid probes were needed. External factory API spend is $0; compute/Codex costs are unavailable. The existing $200 factory ceiling remains in force and no new purchase was made.

Keep native-language phrasebooks beta until a named fluent reviewer accepts them. Four optional sourced history cards exist for Kano, Nairobi, Tokyo and Paris; the rest of the missions have not undergone a complete factual audit, and learning outcomes were not measured. The protected house dialogue hook remains pending; the optional companion can use its existing flat fallback.

Verified H browser bounds: 873.8–1015.1 ms clear-ready cold venue captures, after observed onboarding, desktop Chrome phone tier; warm movement frame-time p95 17.9–19.2 ms over nine 10-second windows. No physical-phone/GPU performance claim. Raw warm frame intervals were not retained, and differing baseline conditions prevent a causal speedup claim. First-draft recipe pass rate is unknown. Largest kit/hero are 141,446 / 37,645 Brotli bytes.

The first three phases have reached production at these recorded releases. Phase 4 is pending the ordinary street proof, integration and release.

| Phase | PR and merge source | CI | Production release |
| --- | --- | --- | --- |
| Story core | [34](https://github.com/kromate/joinallworld/pull/34), [35](https://github.com/kromate/joinallworld/pull/35); `678b6bbe50900561d712ebe35f4932e48227d3b5` | [39101841081](https://github.com/kromate/joinallworld/actions/runs/39101841081) | [39102769792](https://github.com/kromate/joinallworld/actions/runs/39102769792) |
| Scene factory | [44](https://github.com/kromate/joinallworld/pull/44); merge `a5c47a076438d87ac8708a646a67a743d7be2589`, combined release source `48866677dbc25debf3f888211f590436d1ca751a` | [39176204903](https://github.com/kromate/joinallworld/actions/runs/39176204903), [combined PR](https://github.com/kromate/joinallworld/actions/runs/39178158582) | [39180047509](https://github.com/kromate/joinallworld/actions/runs/39180047509) |
| Talk banks | [48](https://github.com/kromate/joinallworld/pull/48); `4631de32e5e784f79104d3a30670831f77e6de2c` | [39184972739](https://github.com/kromate/joinallworld/actions/runs/39184972739), [combined PR](https://github.com/kromate/joinallworld/actions/runs/39186508335) | [39188617351](https://github.com/kromate/joinallworld/actions/runs/39188617351) |

Compressed bytes from the named artifacts are below. Intervening main changes mean these rows do not isolate the effect of each phase.

| Artifact | Startup gzip | Scene-host gzip |
| --- | ---: | ---: |
| Original baseline | 222,613 | 70,912 |
| Phase 1 | 222,619 | 70,897 |
| Phase 2 release | 222,193 | 30,316 |
| Phase 3 release | 222,249 | 30,339 |
| Phase 4 checked H, not final release | 222,362 | 30,356 |

The mode-switch samples were 26.3 / 24.2 ms for trusted click through DOM change and two animation frames on desktop. They do not measure physical display latency. All 6,423 current recipes validate; first-draft pass rate was not retained. The largest kit and hero are 141,446 / 37,645 Brotli bytes.

The final letter will replace the pending Phase 4 row with its exact PR, merge, CI/release, production adoption and owned-resource cleanup. Next owner action after delivery: review the live catalogue and decide when to enable the existing Story setting.
