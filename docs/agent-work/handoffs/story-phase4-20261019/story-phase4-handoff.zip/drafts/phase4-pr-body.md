Recipe venues now use the city recipe’s sky grading and physical-atlas surface treatment. In cities with mapped street doors, Story characters at Roots or Complete can follow the estate gate into a current-city Chapter 3 venue and return through the accepted street journey. Map cards explain the walking route and retain the existing timed trip. Free Roam remains the default; the admin Story Mode flag defaults off.

The surface treatment reuses existing geometry and textures. Scene-owned geometry is disposed while its surface attribute remains attached so the renderer can release the GPU buffer, then the attribute is removed. That repair preserves all 6,423 complete V2 recipes, 298 model files, 13,726 dialogue banks and 284 seed selections from the pre-repair candidate. Mapped coverage includes every Chapter 3 door in Lagos and Ibadan; unmapped venues keep their existing travel path.

Validation at runtime source `96e2e155eec6aee6efe8509e51f942ff16ac92f7`:

- [Hosted CI 39200023908](https://github.com/kromate/joinallworld/actions/runs/39200023908) passes all five executed jobs. Earlier full city contracts, the focused surface disposal check, eight city callers and fourteen matched static V1/V2 visual pairs pass at the recorded scopes.
- Actual combined-game creator and existing-life checks pass at 320/390 px. Eight cache-disabled venue captures across Accra, Nairobi, Paris and Tokyo reach clear, ready scenes in 873.8–1015.1 ms on desktop Chrome’s phone tier after observed onboarding. Nine ordinary movement windows record p95 17.9–19.2 ms; raw frame intervals were not retained. These are desktop measurements.
- Startup 612,007 raw / 222,362 gzip / 195,814 Brotli; shared host 80,169 raw / 30,356 gzip. The original Story startup threshold and every configured byte budget pass.
- Five ordinary park/market returns pass model readiness and exit/entry checks, while texture counts continue to grow 54→96. An exact pre-Phase-4 contrast also grows 45→85. The focused surface buffer repair is covered separately; this change does not resolve or attribute the inherited texture growth.

The ordinary street replay encountered an existing asset-layer 503 at a concave coverage corner. A separate eastward ground tap, server acceptance and then northward tap recovered the same journey, with six observed 200 responses. The protected street authority and collision implementation are unchanged; the exact failed request was not captured. This remains a disclosed limitation.

Final ordinary mapped street door/return/reload evidence and combined PR CI are pending and must be appended before submission. Exact source, sealed measurements, rejected captures, corrected baseline reference and condition limits are recorded in the Story work record and finite evidence packet.
