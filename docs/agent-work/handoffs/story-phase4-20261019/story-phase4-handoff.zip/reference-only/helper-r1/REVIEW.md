PRIVATE PROPOSAL ONLY — NOT LAUNCHED

The old /tmp/story-H-route-third-iQa2PV is terminal and sealed. Never use it.
No command/control file has been written outside this proposal folder.

Parent/operator steps after explicit acceptance:
1. Authorize/start a fresh exact controller through the existing approved process,
   using its canonical /private/tmp/.../controller.cjs path in process argv.
   Wrapper never starts, stops by signal, reconnects or restarts a controller.
2. Operator chooses the visible straight-road bearing and confirms enough clearance
   for the entire proposed batch. Do not batch across corners/seams/doorways needing
   new judgement. Use fewer than3 or shorter legs when warranted. No route inference.
3. Complete one ordinary single leg. Wrapper requires its actual segment-end,
   stopped+accepted fullyready snapshot, monotonic sequence progress, and any due
   screenshot completion. Initial end must be <=10s old. Capture the controller PID,
   exact ps lstart+command string, consumed command SHA/ID and accepted seq.
4. Parent grants exact wrapper hash; operator fills a separate approval.json here
   from fresh observations (confirmedAt <=30s old; launchBefore <=confirmedAt+30s).
   Set approved and both corridor/exclusive-writer flags true only when authorized.
   Do not let any other writer issue command.json during this batch.
5. Execute ONCE, after parent GO:
   python3 /private/tmp/story-H-three-leg-proposal-f7l0i_gw/batch.py --run /private/tmp/story-H-three-leg-proposal-f7l0i_gw/approval.json
   A permanent attempt.json prevents re-execution. Do not remove/repoint it.
6. Wrapper issues at most3 newly-created SAME-key commands, each <=20s, <=60s total.
   Nonce is fresh audit metadata; unchanged controller enforces monotonic IDs and
   expiry (nonce itself is not consumed by controller). No command array or backlog.
   The one command file is replaced only after prior released-input segment-end,
   strict stopped+accepted ready snapshot, and screenshot barrier. While active,
   existing controller retains all500ms guards and ordinary key-up semantics.
7. On failure after input issued, wrapper writes existing STOP only if process is
   still exact/alive, directory unsealed and no terminal/error event is observed.
   Otherwise it preserves terminal directory unchanged. Never remove STOP/restart.
   On success it exits, leaving idle controller for operator review of actual PNGs.
   Existing controller90s idle timeout still applies; no keepalive/autonomous repeat.

Evidence limitations:
- This is source-reviewed, syntax-compiled and pure synthetic boundary rehearsed,
  not browser/runtime validated.15 cases passed; final STOP guard correction is
  outside tested boundary functions and has syntax/source review only.
- Controller segment-end is after key release but BEFORE optional screenshot.
  Wrapper waits for its receipt if due or within5s of the60s threshold. Ambiguous
  threshold timing can conservatively refuse rather than issue another command.
- Snapshot is source-defined250ms after release; if avatar is not yet stopped or
  within4cm of authority, wrapper refuses. It does not obtain another browser read.
- File/PID checks cannot provide an atomic transaction with an independently dying
  process or an unauthorized concurrent file writer. Checks occur immediately before
  replace; exclusive command ownership is required. No command is knowingly written
  after observed terminal/sealed state. Existing expiry, STOP and controller guards
  constrain the narrow check/write race; there is no absolute cross-process guarantee.
- WrapperSIGTERM/SIGINT requests STOP. A hard kill cannot run cleanup, but no further
  command is queued and existing current leg remains<=20s. No server/browser kills.
- Wrapper enforces additional handoff readiness; it never changes/weakens controller.
- This unit changes no appsource, host, Chrome, data, production or provider state.
