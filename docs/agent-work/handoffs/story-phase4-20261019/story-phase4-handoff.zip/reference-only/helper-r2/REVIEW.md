R2 PRIVATE PROPOSAL — NO RUNTIME EXECUTION

Only executable change from R1: replace startup age<=180000ms with a valid,
positive timestamp no later than now. All other wrapper guards are byte-identical.
ready() and boundary() source segments are identical. Saved fixture-rehearsal.py
reproduces the15 original synthetic cases; executed once against R2, all passed.
It imports only Python standard library and the private wrapper definitions with
non-main run_name; never calls wrapper main or accesses controller/browser/game.

First pilot MUST use a NEW exact controller because13367/old third directory is
terminal. Later individually authorized batches may reuse a currently healthy
exact controller regardless of age, provided its exactPID/start/argv, source/hash,
STOP/terminal/sealed-folder/current-command checks and fresh stopped boundary pass.

Each batch MUST run a hash-identical batch.py COPY in its OWN new0700 private folder.
Do not execute in either proposal folder. Do not reuse/delete attempt.json. Do not
copy a prior approval/attempt/events log. Each new batch needs fresh approval and
operator corridor confirmation, exact current consumed command hash/ID/acceptedseq,
end<=10s old and confirmation<=30s old. No unattended chain of batches authorized.

How to prepare a per-batch folder (preparation only; no browser/input):
  python3 - <<'PREP'
from pathlib import Path
import tempfile, os, hashlib
source = Path('/private/tmp/story-H-three-leg-r2-vtbucea6')
expected = '492754ac343035f838ceb767884967c40e011b870c0becca5a58cd1161b0d2cc'
b = (source/'batch.py').read_bytes()
assert hashlib.sha256(b).hexdigest() == expected
folder = Path(tempfile.mkdtemp(prefix='story-H-three-leg-execution-', dir='/private/tmp'))
os.chmod(folder, 0o700)
(folder/'batch.py').write_bytes(b)
(folder/'approval.template.json').write_bytes((source/'approval.template.json').read_bytes())
for p in folder.iterdir(): p.chmod(0o600)
assert hashlib.sha256((folder/'batch.py').read_bytes()).hexdigest() == expected
print(folder)
PREP

After parent GO, operator creates fresh approval.json in THAT new execution folder.
Exact run command, executed solely by authorized operator:
  python3 /private/tmp/NEW_BATCH_FOLDER/batch.py --run /private/tmp/NEW_BATCH_FOLDER/approval.json

All R1 limits remain: same operator-chosen keys at most3legs/60s input, each<=20s;
90s wrapperdeadline; no route selection/queued command array; fresh IDs/nonces/5s
expiries created only after prior input release + stopped accepted ready end and
any due screenshot receipt; no app or controller edits/restart/forced frames.
Nonce is audit metadata; monotonic IDs/expiry are enforced by unchanged controller.
Successful wrapper exits; operator reviews real minute PNGs before a new grant.
Existing90s controller idle timeout remains, so don't create fake keepalives.

Failure uses existing STOP only while exactprocess alive, folderunsealed and no
terminal/error observed. Never write old sealed folder or restart a controller.
Fresh process/root must use canonical /private/tmp path in argv for identity check.

Limitations retained: file/PID checks are not atomic with independently dying
processes or unauthorized writers. Exclusive command ownership is mandatory;
no knowingly terminal write, but a narrow check/write race cannot be eliminated
without changing the controller protocol. No such change is proposed. Screenshot
threshold ambiguity conservatively refuses; a still-moving250ms end refuses.
No runtime integration proof yet. Hard-kill cannot execute wrapper cleanup; at most
current<=20s leg remains, no future command is queued. All current guards unchanged.
